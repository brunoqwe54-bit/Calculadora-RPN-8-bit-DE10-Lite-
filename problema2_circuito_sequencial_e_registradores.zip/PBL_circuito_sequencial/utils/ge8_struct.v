module ge8_struct(input [7:0] x, input [7:0] y, output ge);
  wire [7:0] diff; wire bout;
  subtractor8_struct U(.x(x),.y(y),.d(diff),.bout(bout));
  not (ge, bout);
endmodule
