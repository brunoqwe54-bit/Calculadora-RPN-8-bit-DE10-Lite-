module inc3_mod8(input [2:0] x, output [2:0] s);
  wire c0,c1,unused;
  full_adder fa0(x[0], 1'b0, 1'b1, s[0], c0); // +1
  full_adder fa1(x[1], 1'b0, c0,   s[1], c1);
  full_adder fa2(x[2], 1'b0, c1,   s[2], unused);
endmodule
