module bcd_add3_struct(input [3:0] x, output [3:0] y);
  // Se nibble >=5 → soma 3; senão mantém.
  wire x1ox0, x2and, ge5;
  or  (x1ox0, x[1], x[0]);
  and (x2and, x[2], x1ox0);
  or  (ge5, x[3], x2and);
  wire [3:0] x_plus3; wire ctmp;
  ripple_adder4 ADD3(x, 4'b0011, 1'b0, x_plus3, ctmp);
  mux2_4 M(ge5, x, x_plus3, y);
endmodule
