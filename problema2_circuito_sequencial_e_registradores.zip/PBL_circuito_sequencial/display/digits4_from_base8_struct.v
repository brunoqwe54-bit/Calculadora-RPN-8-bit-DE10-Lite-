module digits4_from_base8_struct(
  input  [7:0] val,
  input  [1:0] base,     // 00 HEX, 01 OCT, 10 DEC, 11 HEX
  output [3:0] d0, output [3:0] d1, output [3:0] d2, output [3:0] d3
);
  // HEX: nibbles; OCT: grupos de 3 bits alinhados em 4; DEC: usa BCD.
  wire [3:0] hx0 = val[3:0],  hx1 = val[7:4],  hx2 = 4'h0, hx3 = 4'h0;
  wire [3:0] oc0 = {1'b0, val[ 2:0]};
  wire [3:0] oc1 = {1'b0, val[ 5:3]};
  wire [3:0] oc2 = {2'b00, val[7:6]};
  wire [3:0] oc3 = 4'h0;

  wire [3:0] dc0,dc1,dc2; bcd8_to_3digits_struct D(val, dc0, dc1, dc2);
  wire [3:0] d0_dec = dc0, d1_dec = dc1, d2_dec = dc2, d3_dec = 4'h0;

  mux4_4 m0(base, hx0, oc0, d0_dec, hx0, d0);
  mux4_4 m1(base, hx1, oc1, d1_dec, hx1, d1);
  mux4_4 m2(base, hx2, oc2, d2_dec, hx2, d2);
  mux4_4 m3(base, hx3, oc3, d3_dec, hx3, d3);
endmodule
