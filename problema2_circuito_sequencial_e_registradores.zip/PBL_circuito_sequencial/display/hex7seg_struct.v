module hex7seg_struct(input [3:0] bin, output [6:0] seg);
  // (0 acende segmento)
  wire [6:0] V0=7'b1000000, V1=7'b1111001, V2=7'b0100100, V3=7'b0110000;
  wire [6:0] V4=7'b0011001, V5=7'b0010010, V6=7'b0000010, V7=7'b1111000;
  wire [6:0] V8=7'b0000000, V9=7'b0010000, VA=7'b0001000, VB=7'b0000011;
  wire [6:0] VC=7'b1000110, VD=7'b0100001, VE=7'b0000110, VF=7'b0001110;

  // Árvore de muxes: primeiro decide bit0, depois bit1, etc.
  wire [6:0] m01,m23,m45,m67,m89,mAB,mCD,mEF;
  mux2_7 u01(bin[0], V0, V1, m01);
  mux2_7 u23(bin[0], V2, V3, m23);
  mux2_7 u45(bin[0], V4, V5, m45);
  mux2_7 u67(bin[0], V6, V7, m67);
  mux2_7 u89(bin[0], V8, V9, m89);
  mux2_7 uAB(bin[0], VA, VB, mAB);
  mux2_7 uCD(bin[0], VC, VD, mCD);
  mux2_7 uEF(bin[0], VE, VF, mEF);

  wire [6:0] m03,m47,m8B,mCF, m07,m8F;
  mux2_7 u03(bin[1], m01, m23, m03);
  mux2_7 u47(bin[1], m45, m67, m47);
  mux2_7 u8B(bin[1], m89, mAB, m8B);
  mux2_7 uCF(bin[1], mCD, mEF, mCF);
  mux2_7 u07(bin[2], m03, m47, m07);
  mux2_7 u8F(bin[2], m8B, mCF, m8F);
  mux2_7 u0F(bin[3], m07, m8F, seg);
endmodule
