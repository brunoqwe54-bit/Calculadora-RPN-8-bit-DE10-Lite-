module bcd8_to_3digits_struct(input [7:0] val, output [3:0] d0, output [3:0] d1, output [3:0] d2);
  // Executa 8 passos (um por bit do valor)
  wire [11:0] s0,s1,s2,s3,s4,s5,s6,s7,s8; assign s0 = 12'd0;
  dd8_step_struct ST0(s0, val[7], s1);
  dd8_step_struct ST1(s1, val[6], s2);
  dd8_step_struct ST2(s2, val[5], s3);
  dd8_step_struct ST3(s3, val[4], s4);
  dd8_step_struct ST4(s4, val[3], s5);
  dd8_step_struct ST5(s5, val[2], s6);
  dd8_step_struct ST6(s6, val[1], s7);
  dd8_step_struct ST7(s7, val[0], s8);
  assign {d2,d1,d0} = s8;
endmodule
