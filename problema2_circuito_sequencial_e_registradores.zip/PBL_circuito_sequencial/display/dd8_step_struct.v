module dd8_step_struct(input [11:0] in12, input inbit, output [11:0] out12);
  // Aplica +3 em cada dígito e insere o próximo bit na cauda.
  wire [3:0] a0,a1,a2; wire [11:0] add3;
  bcd_add3_struct A0(in12[ 3: 0], a0);
  bcd_add3_struct A1(in12[ 7: 4], a1);
  bcd_add3_struct A2(in12[11: 8], a2);
  assign add3  = {a2,a1,a0};
  assign out12 = {add3[10:0], inbit};
endmodule
