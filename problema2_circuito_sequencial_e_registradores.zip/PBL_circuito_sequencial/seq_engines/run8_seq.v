module run8_seq(input clk,input rst_n,input start_pulse,input allow,output busy,output load,output done);
  wire busy_q, busy_d; dffr FB(clk,rst_n,busy_d,busy_q); assign busy = busy_q;

  // load 1 ciclo quando recebe start e está liberado
  wire nbusy; not (nbusy, busy_q);
  and (load, start_pulse, nbusy, allow);

  // Conta 8 passos enquanto busy
  wire [3:0] cnt_q; wire at_one;
  counter4_down_struct CNT(clk,rst_n,load,4'd8,busy_q,cnt_q,at_one);

  // done 1 ciclo quando chega a 1
  wire done_d; and (done_d, busy_q, at_one); dffr FD(clk,rst_n,done_d,done);

  // busy = (busy & ~at_one) | load
  wire not_at_one; not (not_at_one, at_one);
  wire keep; and (keep, busy_q, not_at_one);
  or  (busy_d, keep, load);
endmodule
