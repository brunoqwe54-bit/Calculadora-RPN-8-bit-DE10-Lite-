module pow8_seq_struct(
  input        clk, input rst_n, input start,
  input  [7:0] base, input [7:0] exp,
  output       busy, output done, output sat,
  output [7:0] y
);
  // Pequena “FSM” de 2 bits: IDLE(00) → KICK(01) → WAIT(10)
  wire [1:0] st_q, st_nx;
  wire st_idle, st_kick, st_wait;
  wire n_st1, n_st0;
  not (n_st1, st_q[1]); not (n_st0, st_q[0]);
  and (st_idle, n_st1, n_st0);
  and (st_kick, n_st1, st_q[0]);
  and (st_wait, st_q[1], n_st0);

  // Registradores
  wire [7:0] acc_q, base_q, exp_q; wire sat_q;
  wire load; and (load, start, st_idle);

  // Caso exp=0 logo no início, termina com y=1
  wire exp_is_zero; is_zero8 ZE0(exp, exp_is_zero);

  // Multiplicador é chamado no estado KICK
  wire mul_busy, mul_done; wire [15:0] mul_p;
  wire mul_start = st_kick;
  mul8_shiftadd_seq_struct UM(clk, rst_n, mul_start, acc_q, base_q, mul_busy, mul_done, mul_p);

  // Saturação: se parte alta do produto != 0, o resultado 8-bit será 0xFF
  wire upper_nonzero; or_reduce8 ORU(mul_p[15:8], upper_nonzero);
  wire [7:0] mul_res8_now; mux2_8 MSAT(upper_nonzero, mul_p[7:0], 8'hFF, mul_res8_now);

  // EXP := EXP - 1 a cada multiplicação completa
  wire [7:0] exp_dec; wire bout_dec;
  subtractor8_struct UDEC(exp_q, 8'd1, exp_dec, bout_dec);
  wire exp_dec_is_zero; is_zero8 ZD(exp_dec, exp_dec_is_zero);

  // ACC: carrega 1 no início; depois recebe o produto (já saturado)
  wire [7:0] acc_d0; mux2_8 MA0(load,     acc_q,   8'd1,         acc_d0);
  wire [7:0] acc_nx; mux2_8 MA1(mul_done, acc_d0,  mul_res8_now, acc_nx);
  reg8  RACC(clk, rst_n, 1'b1, acc_nx, acc_q);

  // BASE: carrega valor de entrada no load (e depois mantém)
  wire [7:0] base_nx; mux2_8 MB(load, base_q, base, base_nx);
  reg8  RBASE(clk, rst_n, 1'b1, base_nx, base_q);

  // EXP: carrega no load; decrementa a cada MUL concluída
  wire [7:0] exp_d0; mux2_8 ME0(load,     exp_q,  exp,     exp_d0);
  wire [7:0] exp_nx; mux2_8 ME1(mul_done, exp_d0, exp_dec, exp_nx);
  reg8  REXP(clk, rst_n, 1'b1, exp_nx, exp_q);

  // Latch de saturação (fica 1 se alguma multiplicação saturou)
  wire sat_set; and (sat_set, mul_done, upper_nonzero);
  wire load_or_set; or (load_or_set, load, sat_set);
  wire sat_d; mux1 MS(load_or_set, sat_q, (load ? 1'b0 : 1'b1), sat_d);
  reg1  RSAT(clk, rst_n, 1'b1, sat_d, sat_q);

  // Próximo estado (feito só com muxes e portas)
  // next_idle = (load & ~exp_is_zero) ? 01 : 00
  wire n_exp0; not (n_exp0, exp_is_zero);
  wire cond_idle_next; and (cond_idle_next, load, n_exp0);
  wire [1:0] v00 = 2'b00, v01 = 2'b01, v10 = 2'b10;
  wire [1:0] next_idle; mux2_2 MID(cond_idle_next, v00, v01, next_idle);
  wire [1:0] next_kick = 2'b10;
  wire done_cond; or (done_cond, upper_nonzero, exp_dec_is_zero);
  wire finish_from_wait; and (finish_from_wait, mul_done, done_cond);
  // next_wait: se terminou e deve parar → 00; se terminou e continua → 01; senão → 10
  wire [1:0] from_done; mux2_2 MF0(finish_from_wait, v01, v00, from_done);
  wire [1:0] next_wait; mux2_2 MF1(mul_done, v10, from_done, next_wait);

  wire [1:0] mid1, mid2;
  mux2_2 MST0(st_idle, st_q, next_idle, mid1);
  mux2_2 MST1(st_kick, mid1, next_kick, mid2);
  mux2_2 MST2(st_wait, mid2, next_wait, st_nx);
  reg2  RST(clk, rst_n, 1'b1, st_nx, st_q);

  // busy enquanto não está IDLE
  not (busy, st_idle);

  // done: sobe se exp=0 no load OU quando terminar em WAIT
  wire finish_immediate; and (finish_immediate, load, exp_is_zero);
  wire finish_evt; or (finish_evt, finish_immediate, finish_from_wait);
  dffr FDONE(clk, rst_n, finish_evt, done);

  // y: se terminar imediato, y=1; senão sai o último produto de 8 bits
  wire [7:0] y_pre; mux2_8 MY0(finish_immediate, acc_q, 8'd1, y_pre);
  mux2_8 MY1(mul_done, y_pre, mul_res8_now, y);

  assign sat = (mul_done ? upper_nonzero : 1'b0);
endmodule
