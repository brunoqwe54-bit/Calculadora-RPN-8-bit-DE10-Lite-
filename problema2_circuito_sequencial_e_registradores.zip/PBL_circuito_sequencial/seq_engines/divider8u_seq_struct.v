module divider8u_seq_struct(
  input clk, input rst_n, input start,
  input [7:0] dividend, input [7:0] divisor,
  output busy, output done, output div_by_zero,
  output [7:0] quotient, output [7:0] remainder
);
  // Se divisor=0, não deixa iniciar e sobe flag de div0
  wire div_is_zero; is_zero8 ZD(divisor, div_is_zero);
  wire allow; not (allow, div_is_zero);

  wire load, busy_w, done_w;
  run8_seq SEQ(clk, rst_n, start, allow, busy_w, load, done_w);
  assign busy = busy_w; assign done = done_w;

  // Latch de “divisão por zero”
  wire nbusy; not (nbusy, busy_w);
  wire div0_now; and (div0_now, start, nbusy, div_is_zero);
  wire div0_or;  or  (div0_or, div_by_zero, div0_now);
  wire div0_d;   mux1 MZ(busy_w, 1'b0, div0_or, div0_d);
  dffr FD0(clk, rst_n, div0_d, div_by_zero);

  // Regs internos
  wire [7:0] rem_q, quo_q, dvd_q, divs_q;
  wire [7:0] rem_n, quo_n;

  // Passo do algoritmo
  div_step_struct STEP(rem_q, quo_q, divs_q, dvd_q[7], rem_n, quo_n);

  // Valores iniciais e próximo bit do dividendo
  wire [7:0] rem_init = 8'd0, quo_init = 8'd0, divs_init = divisor, dvd_init = dividend;
  wire [7:0] dvd_step = {dvd_q[6:0], 1'b0};

  // Rede de load/avanço
  wire [7:0] rem_d0, quo_d0, dvd_d0, divs_d0;
  mux2_8 M0(load, rem_q, rem_init, rem_d0);
  mux2_8 M1(load, quo_q, quo_init, quo_d0);
  mux2_8 M2(load, dvd_q, dvd_init, dvd_d0);
  mux2_8 M3(load, divs_q,divs_init,divs_d0);

  wire [7:0] rem_nx, quo_nx, dvd_nx, divs_nx;
  mux2_8 N0(busy_w, rem_d0,  rem_n,    rem_nx);
  mux2_8 N1(busy_w, quo_d0,  quo_n,    quo_nx);
  mux2_8 N2(busy_w, dvd_d0,  dvd_step, dvd_nx);
  mux2_8 N3(busy_w, divs_d0, divs_d0,  divs_nx); // divisor é fixo

  // Regs
  reg8 RREM(clk,rst_n,1'b1,rem_nx , rem_q);
  reg8 RQUO(clk,rst_n,1'b1,quo_nx , quo_q);
  reg8 RDVD(clk,rst_n,1'b1,dvd_nx , dvd_q);
  reg8 RDIV(clk,rst_n,1'b1,divs_nx, divs_q);

  assign quotient  = quo_q;
  assign remainder = rem_q;
endmodule
