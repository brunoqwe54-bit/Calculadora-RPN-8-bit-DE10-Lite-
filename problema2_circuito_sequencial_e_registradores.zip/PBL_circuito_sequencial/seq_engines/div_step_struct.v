module div_step_struct(
  input [7:0] rem_in, input [7:0] quo_in, input [7:0] divisor, input next_bit,
  output [7:0] rem_out, output [7:0] quo_out
);
  // Desloca resto e entra o próximo bit do dividendo
  wire [7:0] rem_shift = {rem_in[6:0], next_bit};

  // Tenta rem_shift - divisor
  wire [7:0] diff; wire bout; subtractor8_struct US(rem_shift, divisor, diff, bout);
  wire ge; not (ge, bout); // se não teve borrow, rem_shift >= divisor

  // Atualiza: se ge, resto vira diff e entra 1 no quociente; caso contrário, mantém e entra 0
  wire [7:0] quo0 = {quo_in[6:0],1'b0};
  wire [7:0] quo1 = {quo_in[6:0],1'b1};
  mux2_8 MRE(ge, rem_shift, diff, rem_out);
  mux2_8 MQO(ge, quo0,      quo1, quo_out);
endmodule
