module mul8_shiftadd_seq_struct(
  input clk, input rst_n, input start,
  input [7:0] a, input [7:0] b,
  output busy, output done,
  output [15:0] p
);
  // Sequência de 8 ciclos
  wire load, busy_w, done_w;
  run8_seq SEQ(clk, rst_n, start, 1'b1, busy_w, load, done_w);
  assign busy = busy_w; assign done = done_w;

  // Regs internos
  wire [7:0] A_q, Q_q, M_q; wire q0 = Q_q[0];

  // Se Q0=1, soma M; se Q0=0, soma 0
  wire [7:0] M_sel; mux2_8 MSEL(q0, 8'd0, M_q, M_sel);

  // A := A + M_sel
  wire [7:0] add_y; wire add_c; ripple_adder8 UADD(A_q, M_sel, 1'b0, add_y, add_c);

  // Desloca {A,Q} com o carry da soma
  wire [7:0] A_step = {add_c, add_y[7:1]};
  wire [7:0] Q_step = {add_y[0], Q_q[7:1]};

  // Load inicial e avanço
  wire [7:0] A_ld, Q_ld, M_ld;
  mux2_8 MA0(load, A_q, 8'd0, A_ld);
  mux2_8 MQ0(load, Q_q, b   , Q_ld);
  mux2_8 MM0(load, M_q, a   , M_ld);

  wire [7:0] A_nx, Q_nx, M_nx;
  mux2_8 MA1(busy_w, A_ld, A_step, A_nx);
  mux2_8 MQ1(busy_w, Q_ld, Q_step, Q_nx);
  mux2_8 MM1(busy_w, M_ld, M_ld ,  M_nx); // M fica parado

  reg8 RA(clk,rst_n,1'b1,A_nx,A_q);
  reg8 RQ(clk,rst_n,1'b1,Q_nx,Q_q);
  reg8 RM(clk,rst_n,1'b1,M_nx,M_q);

  assign p = {A_q,Q_q};
endmodule
