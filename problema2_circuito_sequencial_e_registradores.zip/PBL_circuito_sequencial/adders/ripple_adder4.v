module ripple_adder4(input [3:0] x, input [3:0] y, input cin, output [3:0] s, output cout);
  wire c0,c1,c2;
  full_adder fa0(x[0], y[0], cin, s[0], c0);
  full_adder fa1(x[1], y[1], c0 , s[1], c1);
  full_adder fa2(x[2], y[2], c1 , s[2], c2);
  full_adder fa3(x[3], y[3], c2 , s[3], cout);
endmodule
