module ripple_adder8(input [7:0] x, input [7:0] y, input cin, output [7:0] s, output cout);
  wire [6:0] c;
  full_adder fa0(x[0], y[0], cin,  s[0], c[0]);
  full_adder fa1(x[1], y[1], c[0], s[1], c[1]);
  full_adder fa2(x[2], y[2], c[1], s[2], c[2]);
  full_adder fa3(x[3], y[3], c[2], s[3], c[3]);
  full_adder fa4(x[4], y[4], c[3], s[4], c[4]);
  full_adder fa5(x[5], y[5], c[4], s[5], c[5]);
  full_adder fa6(x[6], y[6], c[5], s[6], c[6]);
  full_adder fa7(x[7], y[7], c[6], s[7], cout);
endmodule
