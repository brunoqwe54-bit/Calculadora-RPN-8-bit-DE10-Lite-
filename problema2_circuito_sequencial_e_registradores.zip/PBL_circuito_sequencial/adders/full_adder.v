module full_adder(input a, input b, input cin, output sum, output cout);
  wire axb, ab, ac, bc;
  xor (axb, a, b);
  xor (sum, axb, cin);
  and (ab, a, b);
  and (ac, a, cin);
  and (bc, b, cin);
  or  (cout, ab, ac, bc);
endmodule
