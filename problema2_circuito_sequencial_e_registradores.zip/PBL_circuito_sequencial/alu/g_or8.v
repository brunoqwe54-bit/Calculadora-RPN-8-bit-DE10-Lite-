module g_or8(input [7:0] a, input [7:0] b, output [7:0] y);
  or (y[0], a[0], b[0]); or (y[1], a[1], b[1]); or (y[2], a[2], b[2]); or (y[3], a[3], b[3]);
  or (y[4], a[4], b[4]); or (y[5], a[5], b[5]); or (y[6], a[6], b[6]); or (y[7], a[7], b[7]);
endmodule
