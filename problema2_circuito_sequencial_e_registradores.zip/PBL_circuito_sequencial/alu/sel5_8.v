module sel5_8(
  input [7:0] a0,input [7:0] a1,input [7:0] a2,input [7:0] a3,input [7:0] a4,
  input s0,input s1,input s2,input s3,input s4,
  output [7:0] y
);
  wire [7:0] m0,m1,m2,m3,m4, t0,t1,t2;
  and8_sel S0(.a(a0), .sel(s0), .y(m0));
  and8_sel S1(.a(a1), .sel(s1), .y(m1));
  and8_sel S2(.a(a2), .sel(s2), .y(m2));
  and8_sel S3(.a(a3), .sel(s3), .y(m3));
  and8_sel S4(.a(a4), .sel(s4), .y(m4));
  g_or8 O0(.a(m0), .b(m1), .y(t0));
  g_or8 O1(.a(m2), .b(m3), .y(t1));
  g_or8 O2(.a(t0), .b(t1), .y(t2));
  g_or8 O3(.a(t2), .b(m4), .y(y));
endmodule
