module g_not8(input [7:0] a, output [7:0] y);
  not (y[0], a[0]); not (y[1], a[1]); not (y[2], a[2]); not (y[3], a[3]);
  not (y[4], a[4]); not (y[5], a[5]); not (y[6], a[6]); not (y[7], a[7]);
endmodule
