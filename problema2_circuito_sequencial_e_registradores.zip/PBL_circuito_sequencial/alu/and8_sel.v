module and8_sel(input [7:0] a, input sel, output [7:0] y);
  and (y[0], a[0], sel); and (y[1], a[1], sel); and (y[2], a[2], sel); and (y[3], a[3], sel);
  and (y[4], a[4], sel); and (y[5], a[5], sel); and (y[6], a[6], sel); and (y[7], a[7], sel);
endmodule
