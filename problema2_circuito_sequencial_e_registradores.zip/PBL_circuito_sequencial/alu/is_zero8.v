module is_zero8(input [7:0] x, output z);
  nor (z, x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7]);
endmodule
