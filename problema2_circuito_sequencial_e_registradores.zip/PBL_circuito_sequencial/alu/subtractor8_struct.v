module subtractor8_struct(input [7:0] x, input [7:0] y, output [7:0] d, output bout);
  wire cout,ovf_unused;
  adder_subtractor8 U(.a(x),.b(y),.mode(1'b1),.y(d),.cout(cout),.overflow(ovf_unused));
  not (bout, cout);
endmodule
