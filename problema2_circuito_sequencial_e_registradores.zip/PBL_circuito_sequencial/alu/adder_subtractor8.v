module adder_subtractor8(
  input [7:0] a, input [7:0] b, input mode,   // mode=0 → add ; mode=1 → sub
  output [7:0] y, output cout, output overflow
);
  // Se for SUB, invertemos B bit a bit.
  wire [7:0] bx;
  xor (bx[0], b[0], mode); xor (bx[1], b[1], mode); xor (bx[2], b[2], mode); xor (bx[3], b[3], mode);
  xor (bx[4], b[4], mode); xor (bx[5], b[5], mode); xor (bx[6], b[6], mode); xor (bx[7], b[7], mode);

  // Ripple adder com carry inicial = mode (0 para ADD; 1 para SUB)
  wire [6:0] c;
  full_adder fa0(a[0], bx[0], mode , y[0], c[0]);
  full_adder fa1(a[1], bx[1], c[0] , y[1], c[1]);
  full_adder fa2(a[2], bx[2], c[1] , y[2], c[2]);
  full_adder fa3(a[3], bx[3], c[2] , y[3], c[3]);
  full_adder fa4(a[4], bx[4], c[3] , y[4], c[4]);
  full_adder fa5(a[5], bx[5], c[4] , y[5], c[5]);
  full_adder fa6(a[6], bx[6], c[5] , y[6], c[6]);
  full_adder fa7(a[7], bx[7], c[6] , y[7], cout);

  // Overflow no sentido assinado
  xor (overflow, c[6], cout);
endmodule
