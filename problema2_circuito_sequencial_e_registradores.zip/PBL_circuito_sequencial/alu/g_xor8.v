module g_xor8(input [7:0] a, input [7:0] b, output [7:0] y);
  xor (y[0], a[0], b[0]); xor (y[1], a[1], b[1]); xor (y[2], a[2], b[2]); xor (y[3], a[3], b[3]);
  xor (y[4], a[4], b[4]); xor (y[5], a[5], b[5]); xor (y[6], a[6], b[6]); xor (y[7], a[7], b[7]);
endmodule
