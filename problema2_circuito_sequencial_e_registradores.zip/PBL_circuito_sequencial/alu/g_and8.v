module g_and8(input [7:0] a, input [7:0] b, output [7:0] y);
  and (y[0], a[0], b[0]); and (y[1], a[1], b[1]); and (y[2], a[2], b[2]); and (y[3], a[3], b[3]);
  and (y[4], a[4], b[4]); and (y[5], a[5], b[5]); and (y[6], a[6], b[6]); and (y[7], a[7], b[7]);
endmodule
