# PBL Verilog — organização por pastas

Estrutura de diretórios e categorização automática por heurística de nomes.

## top
- alc8_top_de10lite_v3.v

## display
- bcd8_to_3digits_struct.v
- bcd_add3_struct.v
- dd8_step_struct.v
- digits4_from_base8_struct.v
- hex7seg_struct.v

## seq_engines
- div_step_struct.v
- divider8u_seq_struct.v
- mul8_shiftadd_seq_struct.v
- pow8_seq_struct.v
- run4_seq.v
- run8_seq.v

## alu
- adder_subtractor8.v
- and8_sel.v
- g_and8.v
- g_not8.v
- g_or8.v
- g_xor8.v
- is_zero8.v
- or_reduce8.v
- sel5_8.v
- subtractor8_struct.v

## adders
- full_adder.v
- ripple_adder4.v
- ripple_adder8.v

## mux
- mux1.v
- mux2_2.v
- mux2_4.v
- mux2_7.v
- mux2_8.v
- mux4_1.v
- mux4_4.v
- mux4_8.v

## regs_sync
- counter4_down_struct.v
- dffr.v
- edge_fall.v
- edge_rise.v
- reg1.v
- reg2.v
- reg3.v
- reg4.v
- reg8.v
- sync2.v

## utils
- ge8_struct.v
- inc3_mod8.v

