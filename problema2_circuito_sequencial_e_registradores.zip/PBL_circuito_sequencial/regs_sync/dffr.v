module dffr(input clk, input rst_n, input d, output q);
  // Flip-flop físico (Intel) com clear assíncrono ativo em 0.
  dffeas u_dff (
    .clk(clk), .d(d), .ena(1'b1),
    .asdata(1'b0), .sload(1'b0), .sclr(1'b0), .aload(1'b0),
    .clrn(rst_n), .prn(1'b1), .q(q)
  );
endmodule
