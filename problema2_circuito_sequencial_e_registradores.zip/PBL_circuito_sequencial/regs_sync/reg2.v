module reg2(input clk,input rst_n,input en,input [1:0] d,output [1:0] q);
  reg1 r0(clk,rst_n,en,d[0],q[0]); reg1 r1(clk,rst_n,en,d[1],q[1]);
endmodule
