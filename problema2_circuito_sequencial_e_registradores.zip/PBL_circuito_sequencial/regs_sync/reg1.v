module reg1(input clk,input rst_n,input en,input d,output q);
  wire di; mux1 M(en, q, d, di); dffr U(clk,rst_n,di,q);
endmodule
