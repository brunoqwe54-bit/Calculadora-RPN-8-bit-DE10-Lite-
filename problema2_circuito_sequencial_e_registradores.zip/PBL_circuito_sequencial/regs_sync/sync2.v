module sync2(input clk, input rst_n, input x, output q);
  wire q1; dffr u1(clk,rst_n,x,q1); dffr u2(clk,rst_n,q1,q);
endmodule
