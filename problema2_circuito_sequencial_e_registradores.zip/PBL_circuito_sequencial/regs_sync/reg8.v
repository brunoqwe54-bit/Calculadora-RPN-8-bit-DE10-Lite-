module reg8(input clk,input rst_n,input en,input [7:0] d,output [7:0] q);
  reg1 r0(clk,rst_n,en,d[0],q[0]); reg1 r1(clk,rst_n,en,d[1],q[1]);
  reg1 r2(clk,rst_n,en,d[2],q[2]); reg1 r3(clk,rst_n,en,d[3],q[3]);
  reg1 r4(clk,rst_n,en,d[4],q[4]); reg1 r5(clk,rst_n,en,d[5],q[5]);
  reg1 r6(clk,rst_n,en,d[6],q[6]); reg1 r7(clk,rst_n,en,d[7],q[7]);
endmodule
