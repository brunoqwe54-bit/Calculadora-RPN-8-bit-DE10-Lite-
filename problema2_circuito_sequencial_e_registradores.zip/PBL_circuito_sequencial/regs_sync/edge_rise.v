module edge_rise(input clk, input rst_n, input x, output p);
  wire qd, nqd; dffr u(clk,rst_n,x,qd); not (nqd, qd); and (p, x, nqd);
endmodule
