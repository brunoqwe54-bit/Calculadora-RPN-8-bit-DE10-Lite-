module edge_fall(input clk, input rst_n, input x, output p);
  wire qd, nx; dffr u(clk,rst_n,x,qd); not (nx, x); and (p, qd, nx);
endmodule
