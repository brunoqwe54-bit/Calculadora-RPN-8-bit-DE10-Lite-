module counter4_down_struct(
  input clk,input rst_n,input load,input [3:0] d,input en,
  output [3:0] q, output at_one
);
  wire [3:0] q_w; assign q = q_w;

  // q_minus1 = q_w - 1 (somar 0xF equivale a subtrair 1)
  wire [3:0] q_minus1; wire dummy;
  ripple_adder4 Usub1(.x(q_w), .y(4'b1111), .cin(1'b0), .s(q_minus1), .cout(dummy));

  // Só conta se q_w!=0
  wire nz01, nz23, nz; 
  or (nz01, q_w[0], q_w[1]); or (nz23, q_w[2], q_w[3]); or (nz, nz01, nz23);
  wire step_en; and (step_en, en, nz);

  // Próximo valor
  wire [3:0] en_val; mux2_4 m0(step_en, q_w, q_minus1, en_val);
  wire [3:0] next_q; mux2_4 m1(load,    en_val, d,       next_q);

  // Estado
  reg4 rq(.clk(clk),.rst_n(rst_n),.en(1'b1),.d(next_q),.q(q_w));

  // Sinaliza quando q==1
  wire n3,n2,n1; not (n3, q_w[3]); not (n2, q_w[2]); not (n1, q_w[1]);
  and (at_one, n3, n2, n1, q_w[0]);
endmodule
