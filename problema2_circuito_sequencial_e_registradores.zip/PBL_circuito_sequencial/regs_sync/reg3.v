module reg3(input clk,input rst_n,input en,input [2:0] d,output [2:0] q);
  reg1 r0(clk,rst_n,en,d[0],q[0]); reg1 r1(clk,rst_n,en,d[1],q[1]); reg1 r2(clk,rst_n,en,d[2],q[2]);
endmodule
