module alc8_top_de10lite_v3(
  input        CLK_50,
  input  [9:0] SW,
  input  [1:0] KEY,   // ativos em 0
  output [9:0] LEDR,
  output [6:0] HEX0, HEX1, HEX2, HEX3
);
  // -------- Entradas/sincronização --------
  wire reset_n = ~SW[8];     // SW8=1 → reset geral
  wire view_in = SW[9];      // 0=editor ; 1=peek pilha
  wire exec_in = SW[6];      // EXEC pelo flanco de subida
  wire [7:0] editor = SW[7:0];

  wire key0_s, key1_s, exec_s, view_s;
  sync2 u_k0(CLK_50,reset_n,KEY[0],key0_s);
  sync2 u_k1(CLK_50,reset_n,KEY[1],key1_s);
  sync2 u_ex(CLK_50,reset_n,exec_in,exec_s);
  sync2 u_vw(CLK_50,reset_n,view_in,view_s);

  wire push_pulse, cycle_pulse, exec_pulse;
  edge_fall e0(CLK_50,reset_n,key0_s,push_pulse);  // ENTER
  edge_fall e1(CLK_50,reset_n,key1_s,cyle_pulse_unused); // não usado visualmente
  // renomeamos para “cycle_pulse”:

  edge_rise e2(CLK_50,reset_n,exec_s,exec_pulse);  // EXEC

  // -------- Seleção de operação (contador 3 bits) --------
  wire [2:0] op_sel_q, op_sel_inc;
  inc3_mod8 INCOP(op_sel_q, op_sel_inc);
  reg3 ROP(CLK_50,reset_n,cycle_pulse,op_sel_inc,op_sel_q);

  // One-hot das operações
  wire n2,n1,n0; not (n2,op_sel_q[2]); not (n1,op_sel_q[1]); not (n0,op_sel_q[0]);
  wire op_is_add, op_is_sub, op_is_mul, op_is_div, op_is_and, op_is_or, op_is_xor, op_is_not;
  and (op_is_add, n2, n1, n0);                    // 000
  and (op_is_sub, n2, n1, op_sel_q[0]);           // 001
  and (op_is_mul, n2, op_sel_q[1], n0);           // 010
  and (op_is_div, n2, op_sel_q[1], op_sel_q[0]);  // 011
  and (op_is_and, op_sel_q[2], n1, n0);           // 100
  and (op_is_or , op_sel_q[2], n1, op_sel_q[0]);  // 101
  and (op_is_xor, op_sel_q[2], op_sel_q[1], n0);  // 110
  and (op_is_not, op_sel_q[2], op_sel_q[1], op_sel_q[0]); // 111

  // SW3 transforma MUL (010) em POW
  wire pow_mod = SW[3];
  wire op_is_pow, n_powmod, op_is_mul_eff;
  and (op_is_pow, op_is_mul, pow_mod);
  not (n_powmod, pow_mod);
  and (op_is_mul_eff, op_is_mul, n_powmod);

  // -------- Pilha 4×8 com válidos --------
  wire [7:0] s0_q,s1_q,s2_q,s3_q;
  wire v0_q,v1_q,v2_q,v3_q;

  // PUSH: sobe a pilha e coloca editor no topo
  wire [7:0] s3_push = s2_q, s2_push = s1_q, s1_push = s0_q, s0_push = editor;
  wire       v3_push = v2_q, v2_push = v1_q, v1_push = v0_q, v0_push = 1'b1;

  // Commit binário (consome s1,s0 → resultado em s0)
  wire [7:0] s3_bin = s3_q, s2_bin = s3_q, s1_bin = s2_q; wire [7:0] s0_bin;
  wire       v3_bin = 1'b0, v2_bin = v3_q, v1_bin = v2_q, v0_bin = 1'b1;

  // Commit unário (NOT): só troca s0
  wire [7:0] s3_uny = s3_q, s2_uny = s2_q, s1_uny = s1_q; wire [7:0] s0_uny;
  wire       v3_uny = v3_q, v2_uny = v2_q, v1_uny = v1_q, v0_uny = v0_q;

  // -------- ULA combinacional + saturação de ADD --------
  wire [7:0] add_y, sub_y; wire add_c, add_v, sub_c_unused, sub_v;
  adder_subtractor8 U_ADD(s1_q, s0_q, 1'b0, add_y, add_c, add_v);
  adder_subtractor8 U_SUB(s1_q, s0_q, 1'b1, sub_y, sub_c_unused, sub_v);

  wire [7:0] and_y, or_y, xor_y, not_y;
  g_and8 U_AND(s1_q, s0_q, and_y);
  g_or8  U_OR (s1_q, s0_q, or_y);
  g_xor8 U_XR (s1_q, s0_q, xor_y);
  g_not8 U_NOT(s0_q, not_y);

  // ADD saturada: se deu carry, fixa em 0xFF
  wire [7:0] add_y_sat; mux2_8 MADD(add_c, add_y, 8'hFF, add_y_sat);

  // Seleção do resultado combinacional conforme a operação
  wire [7:0] res8_comb;
  sel5_8 SELC(add_y_sat, sub_y, and_y, or_y, xor_y,
              op_is_add, op_is_sub, op_is_and, op_is_or, op_is_xor,
              res8_comb);

  // -------- Engines sequenciais: MUL / DIV / POW --------
  // MUL (shift-add)
  wire mul_busy, mul_done; wire [15:0] mul_p;
  wire can_mul; and (can_mul, v0_q, v1_q);
  wire mul_start; and (mul_start, exec_pulse, op_is_mul_eff, can_mul);
  mul8_shiftadd_seq_struct U_MUL(CLK_50,reset_n,mul_start, s1_q,s0_q, mul_busy,mul_done,mul_p);
  wire upper_nonzero_mul; or_reduce8 OM(mul_p[15:8], upper_nonzero_mul);
  wire [7:0] mul_res8_now; mux2_8 MMULS(upper_nonzero_mul, mul_p[7:0], 8'hFF, mul_res8_now);

  // DIV (restoring, unsigned)
  wire div_busy, div_done, div_zero; wire [7:0] div_q, div_r;
  wire s0_is_zero; is_zero8 ZS0(s0_q, s0_is_zero);
  wire ns0; not (ns0, s0_is_zero);
  wire can_div; and (can_div, v0_q, v1_q, ns0);
  wire div_start; and (div_start, exec_pulse, op_is_div, can_div);
  divider8u_seq_struct U_DIV(CLK_50,reset_n,div_start, s1_q,s0_q,
                             div_busy,div_done,div_zero, div_q,div_r);
  wire [7:0] div_res8_now = div_q;

  // POW (base^exp)
  wire pow_busy, pow_done, pow_sat; wire [7:0] pow_y;
  wire can_pow; and (can_pow, v0_q, v1_q);
  wire pow_start; and (pow_start, exec_pulse, op_is_pow, can_pow);
  pow8_seq_struct U_POW(CLK_50, reset_n, pow_start, s1_q, s0_q,
                        pow_busy, pow_done, pow_sat, pow_y);

  // Busy geral (bloqueia novas execuções/push)
  wire busy_or1, busy; or (busy_or1, mul_busy, div_busy); or (busy, busy_or1, pow_busy);
  wire none_busy; not (none_busy, busy);

  // -------- Commit e prioridade de resultados --------
  wire both_valid; and (both_valid, v0_q, v1_q);
  wire any_comb_op; or (any_comb_op, op_is_add, op_is_sub, op_is_and, op_is_or, op_is_xor);
  wire commit_comb_bin; and (commit_comb_bin, exec_pulse, none_busy, any_comb_op, both_valid);
  wire commit_unary;    and (commit_unary,    exec_pulse, none_busy, op_is_not, v0_q);
  wire commit_mul = mul_done;
  wire commit_div = div_done;
  wire commit_pow = pow_done;

  // Pulso específico do ADD (para flags)
  wire add_commit_now; and (add_commit_now, exec_pulse, none_busy, op_is_add, both_valid);

  // s0_bin recebe o resultado com prioridade MUL > DIV > POW > combinacional
  wire [7:0] y1,y2,y3;
  mux2_8 MB0(commit_mul, res8_comb,  mul_res8_now, y1);
  mux2_8 MB1(commit_div, y1,         div_res8_now, y2);
  mux2_8 MB2(commit_pow, y2,         pow_y,        y3);
  assign s0_bin = y3;

  // Resultado do NOT (unário)
  assign s0_uny = not_y;

  // -------- Atualização da pilha (dados) --------
  wire not_view; not (not_view, view_s);
  wire do_push; and (do_push, push_pulse, ~busy, not_view);
  wire do_cbin; or (do_cbin, commit_comb_bin, commit_mul, commit_div, commit_pow);
  wire do_cuny = commit_unary;

  wire rst_assert = ~reset_n;

  // S0
  wire [7:0] s0_mid1, s0_mid2, s0_next, s0_dfix;
  mux2_8 S0A(do_push, s0_q, s0_push, s0_mid1);
  mux2_8 S0B(do_cbin, s0_mid1, s0_bin,  s0_mid2);
  mux2_8 S0C(do_cuny, s0_mid2, s0_uny,  s0_next);
  mux2_8 S0R(rst_assert, s0_next, 8'd0, s0_dfix);

  // S1
  wire [7:0] s1_mid1, s1_mid2, s1_next, s1_dfix;
  mux2_8 S1A(do_push, s1_q, s1_push, s1_mid1);
  mux2_8 S1B(do_cbin, s1_mid1, s1_bin, s1_mid2);
  mux2_8 S1C(do_cuny, s1_mid2, s1_uny, s1_next);
  mux2_8 S1R(rst_assert, s1_next, 8'd0, s1_dfix);

  // S2
  wire [7:0] s2_mid1, s2_mid2, s2_next, s2_dfix;
  mux2_8 S2A(do_push, s2_q, s2_push, s2_mid1);
  mux2_8 S2B(do_cbin, s2_mid1, s2_bin, s2_mid2);
  mux2_8 S2C(do_cuny, s2_mid2, s2_uny, s2_next);
  mux2_8 S2R(rst_assert, s2_next, 8'd0, s2_dfix);

  // S3
  wire [7:0] s3_mid1, s3_mid2, s3_next, s3_dfix;
  mux2_8 S3A(do_push, s3_q, s3_push, s3_mid1);
  mux2_8 S3B(do_cbin, s3_mid1, s3_bin, s3_mid2);
  mux2_8 S3C(do_cuny, s3_mid2, s3_uny, s3_next);
  mux2_8 S3R(rst_assert, s3_next, 8'd0, s3_dfix);

  // Registros da pilha
  reg8 RS0(CLK_50,reset_n,1'b1,s0_dfix,s0_q);
  reg8 RS1(CLK_50,reset_n,1'b1,s1_dfix,s1_q);
  reg8 RS2(CLK_50,reset_n,1'b1,s2_dfix,s2_q);
  reg8 RS3(CLK_50,reset_n,1'b1,s3_dfix,s3_q);

  // -------- Bits de validade (v0..v3) --------
  // v0 tem caminho especial (otimizado em muxes encadeados)
  wire v0_d =
      (v0_push & do_push) ? 1'b1 :
      (rst_assert ? 1'b0 :
       (do_cbin ? v0_bin :
        (do_cuny ? v0_uny : v0_q)));
  reg1 RV0(CLK_50,reset_n,1'b1,v0_d,v0_q);

  // v1..v3 em estilo “igual ao dado” (push/commit/reset)
  wire v1_mid1, v1_mid2, v1_next, v1_dfix;
  mux1 V1A(do_push, v1_q, v1_push, v1_mid1);
  mux1 V1B(do_cbin, v1_mid1, v1_bin, v1_mid2);
  mux1 V1C(do_cuny, v1_mid2, v1_uny, v1_next);
  mux1 V1R(rst_assert, v1_next, 1'b0, v1_dfix);
  reg1 RV1(CLK_50,reset_n,1'b1,v1_dfix,v1_q);

  wire v2_mid1, v2_mid2, v2_next, v2_dfix;
  mux1 V2A(do_push, v2_q, v2_push, v2_mid1);
  mux1 V2B(do_cbin, v2_mid1, v2_bin, v2_mid2);
  mux1 V2C(do_cuny, v2_mid2, v2_uny, v2_next);
  mux1 V2R(rst_assert, v2_next, 1'b0, v2_dfix);
  reg1 RV2(CLK_50,reset_n,1'b1,v2_dfix,v2_q);

  wire v3_mid1, v3_mid2, v3_next, v3_dfix;
  mux1 V3A(do_push, v3_q, v3_push, v3_mid1);
  mux1 V3B(do_cbin, v3_mid1, v3_bin, v3_mid2);
  mux1 V3C(do_cuny, v3_mid2, v3_uny, v3_next);
  mux1 V3R(rst_assert, v3_next, 1'b0, v3_dfix);
  reg1 RV3(CLK_50,reset_n,1'b1,v3_dfix,v3_q);

  // -------- Flags e erros --------
  // SUB negativa (s1 < s0) no instante do commit
  wire [7:0] sub_chk_d_unused; wire sub_borrow;
  subtractor8_struct U_SUBCHK(s1_q, s0_q, sub_chk_d_unused, sub_borrow);
  wire sub_commit_now; and (sub_commit_now, exec_pulse, ~busy, op_is_sub, both_valid);
  wire neg_sub_comm; and (neg_sub_comm, sub_commit_now, sub_borrow);

  // ZERO do resultado que vai ser comitado (com a mesma prioridade)
  wire [7:0] res_for_flags;
  wire [7:0] tA, tB;
  mux2_8 F0(commit_mul, res8_comb, mul_res8_now, tA);
  mux2_8 F1(commit_div, tA,        div_res8_now, tB);
  mux2_8 F2(commit_pow, tB,        pow_y,        res_for_flags);
  wire flag_z; is_zero8 ZF(res_for_flags, flag_z);

  // OVERFLOW (latch):
  //  - ADD: sobe se carry OU overflow assinado; limpa se ADD ok sem overflow
  //  - SUB: sobe se overflow assinado
  //  - MUL/POW: sobe se saturou (produto estourou)
  wire addv_or_c; or (addv_or_c, add_v, add_c);
  wire ovf_pulse_add; and (ovf_pulse_add, add_commit_now, addv_or_c);
  wire ovf_set_sub, ovf_set_mul, ovf_set_pow, ovf_set;
  and (ovf_set_sub, commit_comb_bin, op_is_sub, sub_v);
  and (ovf_set_mul, commit_mul, upper_nonzero_mul);
  and (ovf_set_pow, commit_pow, pow_sat);
  or  (ovf_set, ovf_pulse_add, ovf_set_sub, ovf_set_mul, ovf_set_pow);

  wire add_ok; and (add_ok, op_is_add, addv_or_c);
  wire ovf_clear_add_ok; and (ovf_clear_add_ok, commit_comb_bin, ~add_ok);
  wire ovf_clear_misc; or (ovf_clear_misc, push_pulse, ovf_clear_add_ok, commit_div, commit_unary);
  wire ovf_clear_mul;  and (ovf_clear_mul, commit_mul, ~upper_nonzero_mul);
  wire ovf_clear_pow;  and (ovf_clear_pow, commit_pow, ~pow_sat);
  wire ovf_clear; or (ovf_clear, ovf_clear_misc, ovf_clear_mul, ovf_clear_pow);

  wire ovf_q, ovf_next, keep_ovf;
  mux1 MOVF (ovf_set,   ovf_q, 1'b1, keep_ovf);
  mux1 MOVF2(ovf_clear, keep_ovf, 1'b0, ovf_next);
  reg1 ROVF(CLK_50, reset_n, 1'b1, ovf_next, ovf_q);

  // CARRY (ADD) — latch dedicado no LEDR[3]
  wire carry_now; and (carry_now, add_commit_now, add_c);
  wire carry_hold; or (carry_hold, carry_now, LEDR[3]); // realimentação do próprio LED
  wire carry_clear_add0; and (carry_clear_add0, add_commit_now, ~add_c);

  wire any_logic_sub; or (any_logic_sub, op_is_sub, op_is_and, op_is_or, op_is_xor);
  wire nb; not (nb, busy);
  wire exec_ready; and (exec_ready, exec_pulse, nb, both_valid);
  wire carry_clear_logic; and (carry_clear_logic, exec_ready, any_logic_sub);

  wire carry_clear_div; or (carry_clear_div, commit_div, commit_unary, commit_mul, commit_pow);
  wire carry_clear; or (carry_clear, push_pulse, carry_clear_add0, carry_clear_div, carry_clear_logic);

  wire carry_d; mux1 MCAR(carry_clear, carry_hold, 1'b0, carry_d);
  reg1 RCAR(CLK_50, reset_n, 1'b1, carry_d, LEDR[3]);

  // Erros gerais (underflow de operandos ou DIV/0)
  wire err_under_bin, err_under_uny, err_div0_try, err_new;
  wire any_bin_op; or (any_bin_op, op_is_add, op_is_sub, op_is_and, op_is_or, op_is_xor, op_is_pow);
  wire n_vboth; not (n_vboth, both_valid);
  and (err_under_bin, exec_pulse, any_bin_op, n_vboth);  // faltou operando para operação binária
  wire nv0; not (nv0, v0_q); and (err_under_uny, exec_pulse, op_is_not, nv0); // faltou topo para NOT
  wire try_div_now; and (try_div_now, exec_pulse, op_is_div, both_valid, s0_is_zero);
  or  (err_div0_try, try_div_now, div_zero);
  or  (err_new, err_under_bin, err_under_uny, err_div0_try);

  // Latch de erro geral (LEDR[6])
  wire pe_or; or (pe_or, push_pulse, exec_pulse);
  wire not_err_new; not (not_err_new, err_new);
  wire clear_err; and (clear_err, pe_or, not_err_new);
  wire err_q, err_hold, err_d;
  or  (err_hold, err_new, err_q);
  mux1 MERR(clear_err, err_hold, 1'b0, err_d);
  reg1 RERR(CLK_50,reset_n,1'b1, err_d, err_q);

  // Latch de erro de DISPLAY: “EEE” (div/0 OU sub negativa comitada)
  wire disp_err_set; or (disp_err_set, err_div0_try, neg_sub_comm);
  wire disp_err_q, disp_err_hold, disp_err_d;
  or  (disp_err_hold, disp_err_set, disp_err_q);
  mux1 MDSP(push_pulse, disp_err_hold, 1'b0, disp_err_d); // limpa ao fazer PUSH
  reg1 RERRDSP(CLK_50, reset_n, 1'b1, disp_err_d, disp_err_q);

  // -------- Exibição (editor/peek + base + overlay “EEE”) --------
  wire [7:0] peek_s;
  mux4_8 MPEEK({SW[1],SW[0]}, s0_q, s1_q, s2_q, s3_q, peek_s);
  wire v_peek; mux4_1 MVPEEK({SW[1],SW[0]}, v0_q, v1_q, v2_q, v3_q, v_peek);
  wire [7:0] peek_masked; mux2_8 MPM(v_peek, 8'h00, peek_s, peek_masked);

  wire [7:0] show8; mux2_8 MSHOW(view_s, editor, peek_masked, show8);

  wire [1:0] base_sel = {SW[5],SW[4]};
  wire [3:0] d0,d1,d2,d3; digits4_from_base8_struct FMT(show8, base_sel, d0,d1,d2,d3);

  wire [6:0] HEX0_pre, HEX1_pre, HEX2_pre, HEX3_pre;
  hex7seg_struct h0(d0, HEX0_pre);
  hex7seg_struct h1(d1, HEX1_pre);
  hex7seg_struct h2(d2, HEX2_pre);
  hex7seg_struct h3(d3, HEX3_pre);

  // Apaga tudo durante reset
  wire [6:0] BLANK = 7'b1111111;
  wire [6:0] HEX0_mux, HEX1_mux, HEX2_mux, HEX3_mux;
  mux2_7 MH0(~reset_n, HEX0_pre, BLANK, HEX0_mux);
  mux2_7 MH1(~reset_n, HEX1_pre, BLANK, HEX1_mux);
  mux2_7 MH2(~reset_n, HEX2_pre, BLANK, HEX2_mux);
  mux2_7 MH3(~reset_n, HEX3_pre, BLANK, HEX3_mux);

  // Overlay “EEE” quando há erro de display
  wire [6:0] SEG_E = 7'b0000110;
  wire [6:0] HEX0_out, HEX1_out, HEX2_out, HEX3_out;
  mux2_7 X0(disp_err_q, HEX0_mux, SEG_E, HEX0_out);
  mux2_7 X1(disp_err_q, HEX1_mux, SEG_E, HEX1_out);
  mux2_7 X2(disp_err_q, HEX2_mux, SEG_E, HEX2_out);
  mux2_7 X3(disp_err_q, HEX3_mux, BLANK, HEX3_out);

  assign HEX0 = HEX0_out;
  assign HEX1 = HEX1_out;
  assign HEX2 = HEX2_out;
  assign HEX3 = HEX3_out;

  // -------- LEDs (indicadores) --------
  assign LEDR[2:0] = op_sel_q;                 // operação atual (binário)
  // LEDR[3] = latch de carry (já ligado no registrador RCAR)
  wire ovf_pulse_add_dummy = ovf_pulse_add;    // só para manter a expressão legível
  assign LEDR[4]   = ovf_q | ovf_pulse_add_dummy; // overflow (latch + pulso do ADD)
  assign LEDR[5]   = flag_z;                   // zero do resultado comitado
  assign LEDR[6]   = err_q;                    // erro geral
  assign LEDR[7]   = disp_err_q;               // “EEE”
  assign LEDR[8]   = v0_q;                     // topo válido
  assign LEDR[9]   = busy;                     // alguma engine ativa
endmodule
