module mux2_4(input sel, input [3:0] a, input [3:0] b, output [3:0] y);
  mux1 m0(sel, a[0], b[0], y[0]);
  mux1 m1(sel, a[1], b[1], y[1]);
  mux1 m2(sel, a[2], b[2], y[2]);
  mux1 m3(sel, a[3], b[3], y[3]);
endmodule
