module mux4_8(input [1:0] sel,
              input [7:0] a, input [7:0] b, input [7:0] c, input [7:0] d,
              output [7:0] y);
  wire [7:0] ab, cd;
  mux2_8 m0(sel[0], a, b, ab);
  mux2_8 m1(sel[0], c, d, cd);
  mux2_8 m2(sel[1], ab, cd, y);
endmodule
