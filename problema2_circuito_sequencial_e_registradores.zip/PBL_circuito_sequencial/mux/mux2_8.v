module mux2_8(input sel, input [7:0] a, input [7:0] b, output [7:0] y);
  mux1 m0(sel, a[0], b[0], y[0]); mux1 m1(sel, a[1], b[1], y[1]);
  mux1 m2(sel, a[2], b[2], y[2]); mux1 m3(sel, a[3], b[3], y[3]);
  mux1 m4(sel, a[4], b[4], y[4]); mux1 m5(sel, a[5], b[5], y[5]);
  mux1 m6(sel, a[6], b[6], y[6]); mux1 m7(sel, a[7], b[7], y[7]);
endmodule
