module mux4_4(input [1:0] sel,
              input [3:0] a, input [3:0] b, input [3:0] c, input [3:0] d,
              output [3:0] y);
  wire [3:0] ab, cd;
  mux2_4 m0(sel[0], a, b, ab);
  mux2_4 m1(sel[0], c, d, cd);
  mux2_4 m2(sel[1], ab, cd, y);
endmodule
