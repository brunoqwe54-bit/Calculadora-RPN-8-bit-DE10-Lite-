module mux2_2(input sel, input [1:0] a, input [1:0] b, output [1:0] y);
  mux1 m0(sel, a[0], b[0], y[0]);
  mux1 m1(sel, a[1], b[1], y[1]);
endmodule
