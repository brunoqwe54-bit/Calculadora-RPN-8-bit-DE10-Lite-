module mux1(input sel, input a, input b, output y);
  wire nsel, t0, t1;
  not (nsel, sel);
  and (t0, a, nsel);
  and (t1, b, sel);
  or  (y, t0, t1);
endmodule
