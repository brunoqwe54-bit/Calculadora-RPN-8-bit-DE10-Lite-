module mux4_1(input [1:0] sel, input a, input b, input c, input d, output y);
  wire ab, cd;
  mux1 m0(sel[0], a, b, ab);
  mux1 m1(sel[0], c, d, cd);
  mux1 m2(sel[1], ab, cd, y);
endmodule
